from setuptools import setup

setup(

    name="googlegallary",

    version="0.5.0",

    description="Your can get images by using this package ",


    author="Rahul chauhan",

    packages=['googlegallary'],

)